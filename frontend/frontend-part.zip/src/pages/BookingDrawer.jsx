import { useState, useEffect, useRef } from 'react';
import { slotState } from '../data/mock.js';
import { LIVE, roomSchedule, busyFromSchedule, dayKeyOf, rememberedAdvisor, rememberAdvisor } from '../api.js';
import { QUESTION_LABELS, emptyDetails, detailsBlocker, detailsPayload } from '../data/eventDetails.js';
import EventDetailsForm from '../components/EventDetailsForm.jsx';
import Pill from '../components/Pill.jsx';
import WaitlistOffer from '../components/WaitlistOffer.jsx';
import TestBookingNotice, { TEST_BOOKINGS_ONLY, LIVE25_URL } from '../components/TestBookingNotice.jsx';
import BookingCalendar from '../components/BookingCalendar.jsx';
import WeekCalendar, { CalendarLegend, startOfWeek } from '../components/WeekCalendar.jsx';
import { useRoomWeek } from '../calendarData.js';
import useDialog from '../a11y/useDialog.js';
import { useScrollLock, useIsCompact } from '../useMedia.js';

const MIN = 360, MAX = 1410, STEP = 15; // bookable window: 6:00 AM to 11:30 PM
const DOW = ["S","M","T","W","T","F","S"];
const p2 = n => String(n).padStart(2, "0");
const toHHMM = m => `${p2(Math.floor(m / 60))}:${p2(m % 60)}`;
const fromHHMM = v => { const [h, m] = (v || "").split(":").map(Number); return Number.isNaN(h) || Number.isNaN(m) ? null : h * 60 + m; };
const fmt12 = m => { const h = Math.floor(m / 60); return `${((h + 11) % 12) + 1}:${p2(m % 60)} ${h < 12 ? "AM" : "PM"}`; };
const keyToDate = k => { const [y, m, d] = k.split("-").map(Number); return new Date(y, m - 1, d); };
const labelOf = k => keyToDate(k).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric" });
const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

const timeBox = { padding:"9px 10px", fontSize:15.5, fontWeight:600, border:"2px solid var(--ink)", borderRadius:8, background:"var(--paper)", color:"var(--ink)" };
const navBtn = { width:34, height:34, borderRadius:8, border:"2px solid var(--ink)", color:"var(--ink)", background:"var(--card)", fontWeight:700, fontSize:16 };

export default function BookingDrawer({ room, onClose, onSubmit, onJoinWaitlist, onSearchOrgs, waitlistLine = [], orgs = [] }) {
  const todayKey = dayKeyOf(new Date());
  const now = new Date();
  const pf = room?.prefill;   // date + time picked in Find a Space's "Available on" filter
  const pfStart = pf ? fromHHMM(pf.from) : null, pfEnd = pf ? fromHHMM(pf.to) : null;
  const [month, setMonth] = useState(pf ? { y: +pf.date.slice(0, 4), m: +pf.date.slice(5, 7) - 1 } : { y: now.getFullYear(), m: now.getMonth() });
  const [dates, setDates] = useState(pf ? [pf.date] : []);   // selected day keys
  const [start, setStart] = useState(pfStart != null ? clamp(pfStart, MIN, MAX) : 18 * 60);
  const [end, setEnd] = useState(pfEnd != null ? clamp(pfEnd, MIN, MAX) : 19 * 60);
  // Each chosen day has its own time. start/end above are the time new days start with.
  const [times, setTimes] = useState(pf ? { [pf.date]: { start: pfStart != null ? clamp(pfStart, MIN, MAX) : 18 * 60, end: pfEnd != null ? clamp(pfEnd, MIN, MAX) : 19 * 60 } } : {});
  const [org, setOrg] = useState(null);
  const [confirming, setConfirming] = useState(false);
  const [showCal, setShowCal] = useState(false);       // the big calendar view
  const [done, setDone] = useState(false);
  // Test-booking notice: holds what to run if the person chooses to continue.
  const [notice, setNotice] = useState(null);   // null | { waitlist, run }
  const guarded = (run, waitlist = false) => () =>
    TEST_BOOKINGS_ONLY ? setNotice({ waitlist, run }) : run();
  const [busy, setBusy] = useState(false);
  const [wlMsg, setWlMsg] = useState("");
  const [eventName, setEventName] = useState("");
  const [names, setNames] = useState({});            // an optional event name for one day; blank = use the main name
  const [det, setDet] = useState(emptyDetails);       // attendance, description, event questions, co-hosts, advisor, policy (EventDetailsForm)
  // Pre-fill the club's program advisor from last time, until the user edits the field.
  useEffect(() => { if (!det.advisorTouched) setDet(d => ({ ...d, advisor: rememberedAdvisor(orgs.length > 1 ? org : orgs[0]) })); }, [org, orgs.length]);   // eslint-disable-line react-hooks/exhaustive-deps
  const [error, setError] = useState("");
  const [live, setLive] = useState({});                // live busy intervals by day key
  const [schedErr, setSchedErr] = useState("");   // set when the room's schedule can't be loaded
  const loaded = useRef(new Set());
  const panel = useRef(null);
  // Keyboard and screen readers: focus moves into the drawer, Tab stays inside, Escape closes it.
  useDialog(panel, { open: !!room, onClose });
  // Phones and tablets: the page behind doesn't scroll while the drawer is open (desktop unchanged).
  const compact = useIsCompact();
  useScrollLock(!!room);
  const wide = !compact;     // desktop: one big window, calendar on the left and the booking form on the right
  const [weekStart, setWeekStart] = useState(() => startOfWeek(new Date()));
  const { events: weekEvents, loading: weekLoading, error: weekError, retry: weekRetry } = useRoomWeek(room, weekStart);

  useEffect(() => {
    if (!done) return;
    const t = setTimeout(onClose, 1300);
    return () => clearTimeout(t);
  }, [done]);

  // Load the room's schedule for the month on screen (live mode only).
  useEffect(() => {
    if (!LIVE || !room) return;
    const id = `${room.id}|${month.y}-${month.m}`;
    if (loaded.current.has(id)) return;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const first = new Date(month.y, month.m, 1), last = new Date(month.y, month.m + 1, 0);
    if (last < today) return;
    loaded.current.add(id);
    setSchedErr("");
    roomSchedule(room.id, dayKeyOf(first < today ? today : first), dayKeyOf(last))
      .then(items => setLive(prev => {
        const next = { ...prev }, add = busyFromSchedule(items);
        for (const k in add) next[k] = [...(next[k] || []), ...add[k]];
        return next;
      })).catch(e => { loaded.current.delete(id); setSchedErr(e.message || "Couldn't load this room's schedule."); });
  }, [room?.id, month.y, month.m]);

  if (!room) return null;

  // [startMin, endMin, "booked" | "requested"] for a day
  const intervalsFor = key => {
    if (LIVE) return live[key] || [];
    const out = [];
    for (let h = 9; h <= 20; h++) {
      const st = slotState(room, key, `${h}:00`);
      if (st !== "open") out.push([h * 60, (h + 1) * 60, st === "taken" ? "booked" : "requested"]);
    }
    return out;
  };
  const nameOf = k => (names[k] || "").trim() || eventName.trim();   // the event name for one day
  const tOf = k => times[k] || { start, end };   // the time chosen for one day
  const overlaps = key => {
    const t = tOf(key);
    const hit = intervalsFor(key).filter(([s, e]) => s < t.end && e > t.start);
    return { booked: hit.filter(h => h[2] === "booked"), requested: hit.filter(h => h[2] === "requested") };
  };

  const sorted = [...dates].sort();
  const rangeOk = sorted.every(k => tOf(k).end > tOf(k).start);
  // a conflict = another club's booking OR request overlaps the chosen date + time
  const conflicts = sorted.filter(k => { const o = overlaps(k); return o.booked.length > 0 || o.requested.length > 0; });
  const needOrg = orgs.length > 1 && !org;
  const bookingOrg = orgs.length > 1 ? org : orgs[0];
  const blocker = detailsBlocker(det, room.cap);   // what's still missing from the event details ("" = nothing)
  const canReview = sorted.length > 0 && rangeOk && conflicts.length === 0 && !needOrg && sorted.every(k => nameOf(k)) && !blocker;   // every day needs a name: its own, or the main one

  // The top time box sets the default for new days, and moves any day that is still on that default.
  const changeDefault = (ns, ne) => {
    setTimes(t => Object.fromEntries(Object.entries(t).map(([k, v]) => [k, v.start === start && v.end === end ? { start: ns, end: ne } : v])));
    setStart(ns); setEnd(ne);
  };
  const setStartClamped = m => { const s = clamp(m, MIN, MAX - STEP); changeDefault(s, end <= s ? Math.min(s + 60, MAX) : end); };
  const setEndClamped = m => { changeDefault(start, clamp(m, start + STEP, MAX)); };
  // One day's own time.
  const setDayTime = (k, which, m) => {
    const cur = tOf(k);
    const next = which === "start"
      ? (() => { const s = clamp(m, MIN, MAX - STEP); return { start: s, end: cur.end <= s ? Math.min(s + 60, MAX) : cur.end }; })()
      : { start: cur.start, end: clamp(m, cur.start + STEP, MAX) };
    setTimes(t => ({ ...t, [k]: next })); setStart(next.start); setEnd(next.end);
  };
  const sameForAll = () => { const first = tOf(sorted[0]); setTimes(t => Object.fromEntries(sorted.map(k => [k, { ...first }]))); };
  const addDay = (k, s, e) => {
    setDates(ds => ds.includes(k) ? ds : [...ds, k]);
    setTimes(t => ({ ...t, [k]: s != null ? { start: s, end: e } : (t[k] || { start, end }) }));
    if (s != null) { setStart(s); setEnd(e); }
  };
  const toggleDate = k => {
    if (dates.includes(k)) { setDates(ds => ds.filter(x => x !== k)); setTimes(t => { const n = { ...t }; delete n[k]; return n; }); }
    else { addDay(k); setWeekStart(startOfWeek(keyToDate(k))); }
  };

  const shiftMonth = d => setMonth(({ y, m }) => { const x = new Date(y, m + d, 1); return { y: x.getFullYear(), m: x.getMonth() }; });
  const cur = new Date(now.getFullYear(), now.getMonth(), 1);
  const canPrev = new Date(month.y, month.m, 1) > cur;
  const canNext = new Date(month.y, month.m, 1) < new Date(now.getFullYear(), now.getMonth() + 6, 1);
  const lead = new Date(month.y, month.m, 1).getDay();
  const dim = new Date(month.y, month.m + 1, 0).getDate();
  const cells = [...Array(lead).fill(null), ...Array.from({ length: dim }, (_, i) => `${month.y}-${p2(month.m + 1)}-${p2(i + 1)}`)];
  const monthLabel = new Date(month.y, month.m, 1).toLocaleDateString("en-US", { month: "long", year: "numeric" });

  const submit = async () => {
    setBusy(true); setError("");
    try {
      const picks = sorted.map(k => ({ key: k, label: labelOf(k), start: toHHMM(tOf(k).start), end: toHHMM(tOf(k).end), event: nameOf(k) }));
      rememberAdvisor(bookingOrg, det.advisor.trim());
      const failed = (await onSubmit(room, picks, bookingOrg, eventName.trim(), detailsPayload(det, bookingOrg))) || [];
      if (failed.length === 0) { setDone(true); return; }
      setDates(failed.map(f => f.pick.key)); setConfirming(false);
      setError(failed.map(f => `${f.pick.label}: ${f.msg}`).join(" "));
    } catch (e) { setError(e.message || "Couldn't send the request."); setConfirming(false); }
    finally { setBusy(false); }
  };

  const joinWl = async () => {
    setBusy(true); setError(""); setWlMsg("");
    try {
      const picks = conflicts.map(k => ({ key: k, label: labelOf(k), start: toHHMM(tOf(k).start), end: toHHMM(tOf(k).end), event: nameOf(k) }));
      rememberAdvisor(bookingOrg, det.advisor.trim());
      const failed = (await onJoinWaitlist(room, picks, bookingOrg, eventName.trim(), detailsPayload(det, bookingOrg))) || [];
      const ok = picks.length - failed.length;
      if (ok) setWlMsg(`✓ You joined the waitlist for ${ok} time slot${ok === 1 ? "" : "s"}. See your spot under My requests.`);
      setDates(ds => ds.filter(k => !conflicts.includes(k) || failed.some(f => f.pick.key === k)));
      if (failed.length) setError(failed.map(f => `${f.pick.label}: ${f.msg}`).join(" "));
    } catch (e) { setError(e.message || "Couldn't join the waitlist."); }
    finally { setBusy(false); }
  };

  // Wide layout: click or drag on the calendar to add that day and use that time.
  const pickInline = (key, s, e) => {
    addDay(key, s, e); setError("");   // this day gets this time; the other days keep theirs
    const d = keyToDate(key); setMonth({ y: d.getFullYear(), m: d.getMonth() });
  };
  const mineEvents = sorted.map(k => {
    const d = keyToDate(k);
    return { id: `mine-${k}`, kind: "mine", title: nameOf(k) || "Your choice", sub: conflicts.includes(k) ? "Overlaps another booking" : "Your request",
      start: new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, tOf(k).start), end: new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0, tOf(k).end) };
  });

  // A time picked on the big calendar: add that day and use its time.
  const pickFromCalendar = ({ key, start: s, end: e }) => {
    addDay(key, s, e); setShowCal(false); setError("");
    const d = keyToDate(key); setMonth({ y: d.getFullYear(), m: d.getMonth() });
  };

  return (
    <>
      <div onClick={onClose} aria-hidden="true" style={{ position:"fixed", inset:0, background:"rgba(27,42,74,.28)", zIndex:40 }} />
      <div ref={panel} className="booking-panel" role="dialog" aria-modal="true" aria-labelledby="booking-title" aria-describedby="booking-sub" tabIndex={-1}
        style={wide
          ? { position:"fixed", top:"3vh", bottom:"3vh", left:0, right:0, margin:"0 auto", width:"min(1220px, 96vw)", background:"var(--card)", zIndex:50,
              border:"2px solid var(--ink)", borderRadius:16, boxShadow:"var(--shadow-lift)", display:"flex", flexDirection:"row", overflow:"hidden" }
          : { position:"fixed", top:0, right:0, bottom:0, width:500, maxWidth:"94vw", background:"var(--card)",
              zIndex:50, boxShadow:"-8px 0 40px rgba(27,42,74,.18)", display:"flex", flexDirection:"column" }}>
        {wide && (
          <div style={{ flex:"1 1 0", minWidth:0, padding:"20px 22px", display:"flex", flexDirection:"column", gap:12, overflowY:"auto", background:"var(--paper)", borderRight:"2px solid var(--ink)" }}>
            <div>
              <div style={{ fontSize:20, fontWeight:800 }}>Everyone's bookings</div>
              <div style={{ fontSize:14.5, color:"var(--ink-faint)" }}>Click an empty time, or drag to choose how long. Your pick shows in yellow.</div>
            </div>
            {weekError && (
              <div role="alert" style={{ padding:"10px 14px", borderRadius:10, background:"var(--red-wash)", color:"var(--red)", border:"2px solid var(--red)", fontSize:14, fontWeight:600 }}>
                Couldn't load this week ({weekError}). <button onClick={weekRetry} style={{ color:"var(--link)", fontWeight:700, textDecoration:"underline" }}>Try again</button>
              </div>
            )}
            <WeekCalendar weekStart={weekStart} onWeekChange={setWeekStart} events={[...weekEvents, ...mineEvents]} loading={weekLoading} noPast
              onSelect={pickInline} maxHeight={620} />
            <CalendarLegend />
          </div>
        )}
        <div style={wide ? { width:430, flexShrink:0, display:"flex", flexDirection:"column", position:"relative", minHeight:0 }
                         : { display:"flex", flexDirection:"column", flex:1, minHeight:0, position:"relative" }}>
        <div className="booking-head" style={{ padding:"20px 22px", borderBottom:"1px solid var(--line)" }}>
          <Pill status={room.status} small />
          <h2 id="booking-title" style={{ fontSize:24, fontWeight:800, margin:"10px 0 3px" }}>{room.name}</h2>
          <div id="booking-sub" style={{ fontSize:15.6, color:"var(--ink-faint)" }}>{room.building} · Holds {room.cap}</div>
          <button className="booking-close" onClick={onClose} aria-label="Close booking" style={{ position:"absolute", top:18, right:20, width:30, height:30,
            borderRadius:8, background:"var(--line-soft)" }}>×</button>
        </div>

        <div className="booking-body" style={{ padding:"18px 22px", overflowY:"auto", flex:1, overscrollBehavior:"contain" }}>
          {error && <div role="alert" style={{ color:"var(--red)", fontWeight:600, fontSize:14.5, marginBottom:12 }}>{error}</div>}

          {confirming && (
            <div>
              <div style={{ fontSize:22, fontWeight:700, marginBottom:6 }}>Confirm your request</div>
              <div style={{ fontSize:15, color:"var(--ink-soft)", marginBottom:14 }}>Please check the details. Nothing is sent until you confirm.</div>
              <div style={{ border:"2px solid var(--ink)", borderRadius:10, padding:"14px 16px", background:"var(--paper)" }}>
                <div style={{ fontWeight:700, fontSize:17 }}>{room.name}</div>
                <div style={{ fontSize:14, color:"var(--ink-faint)", marginBottom:8 }}>{room.building}</div>
                {!sorted.some(k => nameOf(k) !== eventName.trim()) && <div style={{ fontSize:15, marginBottom:6 }}>Event: <b>{eventName.trim()}</b></div>}
                {bookingOrg && <div style={{ fontSize:15, marginBottom:6 }}>Booking for: <b>{bookingOrg}</b></div>}
                {(() => { const p = detailsPayload(det, bookingOrg), inc = Object.keys(QUESTION_LABELS).filter(k => det.questions[k]).map(k => QUESTION_LABELS[k]); return (<>
                  <div style={{ fontSize:15, marginBottom:6 }}>Event type: <b>{p.eventType}</b></div>
                  <div style={{ fontSize:15, marginBottom:6 }}>Expected attendance: <b>{p.headcount}</b></div>
                  <div style={{ fontSize:15, marginBottom:6, whiteSpace:"pre-wrap", overflowWrap:"anywhere" }}>About: {p.description}</div>
                  <div style={{ fontSize:15, marginBottom:6 }}>Includes: <b>{inc.length ? inc.join(", ") : "nothing special"}</b></div>
                  {p.coHostNames.length > 0 && <div style={{ fontSize:15, marginBottom:6 }}>Co-hosting with: <b>{p.coHostNames.join(", ")}</b></div>}
                  {p.advisor && <div style={{ fontSize:15, marginBottom:6 }}>Program advisor: <b>{p.advisor}</b></div>}
                </>); })()}
                {sorted.map(k => <div key={k} style={{ fontSize:15, padding:"3px 0" }}><b>{labelOf(k)}</b> · {fmt12(tOf(k).start)} – {fmt12(tOf(k).end)}{sorted.some(j => nameOf(j) !== eventName.trim()) && <> · {nameOf(k)}</>}</div>)}
              </div>
            </div>
          )}

          <div style={{ display: confirming ? "none" : "block" }}>
            {schedErr && <div role="alert" style={{ marginBottom:14, padding:"10px 14px", borderRadius:10, background:"var(--red-wash)",
              color:"var(--red)", border:"2px solid var(--red)", fontSize:14, fontWeight:600 }}>
              Couldn't load this room's schedule ({schedErr}), so some times may look free when they aren't. Change months or reopen to retry.</div>}
            {orgs.length > 1 && (
              <div style={{ marginBottom:18 }}>
                <div style={{ fontSize:15.6, fontWeight:700, marginBottom:8 }}>Booking for which club?</div>
                <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
                  {orgs.map(o => (
                    <button key={o} onClick={() => setOrg(o)} style={{ padding:"9px 15px", borderRadius:999, fontSize:15, fontWeight:700,
                      border:"2px solid var(--ink)", color:"var(--ink)", background: org === o ? "var(--blue)" : "var(--card)" }}>{o}</button>
                  ))}
                </div>
              </div>
            )}

            {!wide && <button onClick={() => setShowCal(true)} style={{ width:"100%", marginBottom:18, padding:"12px 14px", borderRadius:10, fontSize:15.5, fontWeight:700,
              color:"var(--ink)", background:"var(--blue-wash)", border:"2px solid var(--ink)", display:"flex", alignItems:"center", justifyContent:"center", gap:8 }}>
              <span aria-hidden="true">📅</span> See all bookings on a calendar
            </button>}

            <div style={{ fontSize:15.6, fontWeight:700, marginBottom:10 }}>Choose days — tap more than one</div>
            <div style={{ border:"2px solid var(--ink)", borderRadius:12, padding:12, background:"var(--paper)" }}>
              <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:10 }}>
                <button onClick={() => shiftMonth(-1)} disabled={!canPrev} aria-label="Previous month" style={{ ...navBtn, opacity: canPrev ? 1 : .35 }}>‹</button>
                <div style={{ fontWeight:700, fontSize:16.5 }}>{monthLabel}</div>
                <button onClick={() => shiftMonth(1)} disabled={!canNext} aria-label="Next month" style={{ ...navBtn, opacity: canNext ? 1 : .35 }}>›</button>
              </div>
              <div style={{ display:"grid", gridTemplateColumns:"repeat(7, 1fr)", gap:4, textAlign:"center" }}>
                {DOW.map((d, i) => <div key={i} style={{ fontSize:12.5, fontWeight:700, color:"var(--ink-faint)", padding:"2px 0" }}>{d}</div>)}
                {cells.map((k, i) => {
                  if (!k) return <div key={`e${i}`} />;
                  const past = k < todayKey, sel = dates.includes(k);
                  const clash = sel && conflicts.includes(k);
                  return (
                    <button key={k} className="cal-day" disabled={past} onClick={() => toggleDate(k)} aria-label={labelOf(k)} aria-pressed={sel}
                      style={{ height:40, borderRadius:8, fontSize:15, fontWeight:700,
                        border: `2px solid ${clash ? "var(--red)" : sel ? "var(--ink)" : k === todayKey ? "var(--ink-faint)" : "transparent"}`,
                        background: clash ? "var(--red-wash)" : sel ? "var(--blue)" : "var(--card)",
                        color: past ? "var(--ink-faint)" : clash ? "var(--red)" : "var(--ink)", opacity: past ? .45 : 1,
                        cursor: past ? "not-allowed" : "pointer" }}>{Number(k.slice(8))}</button>
                  );
                })}
              </div>
            </div>

            <div style={{ fontSize:15.6, fontWeight:700, margin:"20px 0 2px" }}>Choose a time</div>
            <div style={{ fontSize:13.5, color:"var(--ink-faint)", marginBottom:10 }}>This is the time for days you add. Each day below can have its own time.</div>
            <div style={{ border:"2px solid var(--ink)", borderRadius:12, padding:"14px 14px 10px", background:"var(--paper)" }}>
              <div style={{ display:"flex", gap:12, alignItems:"center", flexWrap:"wrap", marginBottom:10 }}>
                <label style={{ fontSize:14, fontWeight:600, color:"var(--ink-soft)" }}>From{" "}
                  <input id="book-start" type="time" step={900} value={toHHMM(start)} style={timeBox}
                    onChange={e => { const v = fromHHMM(e.target.value); if (v !== null) setStartClamped(v); }} />
                </label>
                <label style={{ fontSize:14, fontWeight:600, color:"var(--ink-soft)" }}>To{" "}
                  <input id="book-end" type="time" step={900} value={toHHMM(end)} style={timeBox}
                    onChange={e => { const v = fromHHMM(e.target.value); if (v !== null) setEndClamped(v); }} />
                </label>
                <div style={{ marginLeft:"auto", fontWeight:700, fontSize:15 }}>{fmt12(start)} – {fmt12(end)}</div>
              </div>
              <label style={{ display:"block", fontSize:13.5, fontWeight:600, color:"var(--ink-soft)" }}>Start
                <input id="slide-start" type="range" min={MIN} max={MAX - STEP} step={STEP} value={clamp(start, MIN, MAX - STEP)}
                  onChange={e => setStartClamped(+e.target.value)} style={{ width:"100%", accentColor:"#1B2A4A" }} />
              </label>
              <label style={{ display:"block", fontSize:13.5, fontWeight:600, color:"var(--ink-soft)", marginTop:4 }}>End
                <input id="slide-end" type="range" min={MIN + STEP} max={MAX} step={STEP} value={clamp(end, MIN + STEP, MAX)}
                  onChange={e => setEndClamped(+e.target.value)} style={{ width:"100%", accentColor:"#1B2A4A" }} />
              </label>
              <div style={{ display:"flex", justifyContent:"space-between", fontSize:12.5, color:"var(--ink-faint)" }}>
                <span>6 AM</span><span>12 PM</span><span>6 PM</span><span>11:30 PM</span>
              </div>
            </div>

            {sorted.length > 0 && (
              <div style={{ background:"var(--blue-wash)", borderRadius:10, padding:"13px 15px", marginTop:18 }}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", gap:8, marginBottom:6, flexWrap:"wrap" }}>
                  <div style={{ fontSize:15.6, fontWeight:700 }}>Your selection ({sorted.length} day{sorted.length === 1 ? "" : "s"})</div>
                  {sorted.length > 1 && <button onClick={sameForAll} style={{ color:"var(--link)", fontWeight:700, fontSize:13.5, textDecoration:"underline" }}>Use {fmt12(tOf(sorted[0]).start)} – {fmt12(tOf(sorted[0]).end)} for every day</button>}
                </div>
                {sorted.map(k => {
                  const o = overlaps(k), t = tOf(k);
                  return (
                    <div key={k} style={{ padding:"7px 0", color:"var(--ink-soft)", fontSize:15.5, borderTop:"1px solid var(--line)" }}>
                      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                        <b style={{ color:"var(--ink)" }}>{labelOf(k)}</b>
                        <button onClick={() => toggleDate(k)} aria-label={`Remove ${labelOf(k)}`} style={{ fontSize:19, color:"var(--ink-faint)" }}>×</button>
                      </div>
                      <div style={{ display:"flex", gap:8, alignItems:"center", flexWrap:"wrap", margin:"4px 0" }}>
                        <label style={{ fontSize:13.5, fontWeight:600 }}>From{" "}
                          <input type="time" step={900} value={toHHMM(t.start)} aria-label={`${labelOf(k)} start time`} style={{ ...timeBox, padding:"6px 8px", fontSize:14.5 }}
                            onChange={e => { const v = fromHHMM(e.target.value); if (v !== null) setDayTime(k, "start", v); }} />
                        </label>
                        <label style={{ fontSize:13.5, fontWeight:600 }}>To{" "}
                          <input type="time" step={900} value={toHHMM(t.end)} aria-label={`${labelOf(k)} end time`} style={{ ...timeBox, padding:"6px 8px", fontSize:14.5 }}
                            onChange={e => { const v = fromHHMM(e.target.value); if (v !== null) setDayTime(k, "end", v); }} />
                        </label>
                      </div>
                      <input value={names[k] || ""} onChange={e => setNames(n => ({ ...n, [k]: e.target.value }))} maxLength={100}
                        placeholder={eventName.trim() ? `Event name (same as above: ${eventName.trim()})` : "Event name for this day"} aria-label={`${labelOf(k)} event name`}
                        style={{ width:"100%", padding:"7px 10px", fontSize:14.5, border:"2px solid var(--ink)", borderRadius:8, background:"var(--paper)", outline:"none", margin:"2px 0 4px" }} />
                      {(o.booked.length > 0 || o.requested.length > 0) && <div style={{ color:"var(--red)", fontWeight:600, fontSize:14 }}>
                        Time conflict: {o.booked.length > 0
                          ? `already booked ${o.booked.map(([s, e]) => `${fmt12(s)}–${fmt12(e)}`).join(", ")}`
                          : "another club has already requested this time"}. Join the waitlist below, or pick another time or day.</div>}
                    </div>
                  );
                })}
              </div>
            )}

            <EventDetailsForm value={det} onChange={setDet} eventName={eventName} onEventName={setEventName} org={bookingOrg} cap={room.cap} search={onSearchOrgs} />

            {wlMsg && <div role="status" style={{ color:"var(--green)", fontWeight:600, fontSize:15, marginTop:14 }}>{wlMsg}</div>}
            {conflicts.length > 0 && !needOrg && onJoinWaitlist && (
              <WaitlistOffer named={conflicts.every(k => nameOf(k))} blocker={blocker} roomName={room.name} days={conflicts} start={start} end={end} times={times} line={waitlistLine} busy={busy} onJoin={guarded(joinWl, true)} />
            )}
          </div>
        </div>

        <div className="booking-foot" style={{ padding:"16px 22px", borderTop:"1px solid var(--line)", background:"var(--paper)" }}>
          {done ? (
            <div role="status" style={{ color:"var(--green)", fontWeight:600, fontSize:16.8, textAlign:"center" }}>
              ✓ {sorted.length} request{sorted.length === 1 ? "" : "s"} sent — you'll get a notification when reviewed
              {TEST_BOOKINGS_ONLY && <div style={{ marginTop:6, fontSize:14.5, fontWeight:500, color:"var(--ink-soft)" }}>
                Test booking only: the room isn't reserved in 25Live.{" "}
                <a href={LIVE25_URL} target="_blank" rel="noopener noreferrer" style={{ color:"var(--link)", fontWeight:700 }}>Book it in 25Live ↗</a></div>}
            </div>
          ) : confirming ? (
            <div style={{ display:"flex", gap:10 }}>
              <button onClick={() => setConfirming(false)} style={{ flex:1, padding:"13px", borderRadius:10, fontSize:16, fontWeight:700,
                border:"2px solid var(--ink)", background:"var(--card)", color:"var(--ink)" }}>Back</button>
              <button disabled={busy} onClick={guarded(submit)} style={{ flex:2, padding:"13px", borderRadius:10,
                fontSize:16, fontWeight:700, color:"var(--ink)", background:"var(--blue)" }}>{busy ? "Sending…" : "Confirm request"}</button>
            </div>
          ) : (
            <button disabled={!canReview} onClick={() => { setError(""); setConfirming(true); }} style={{
              width:"100%", padding:"13px", borderRadius:10, fontSize:18, fontWeight:700, color:"var(--ink)",
              background: canReview ? "var(--blue)" : "var(--line-soft)" }}>
              {needOrg ? "Choose a club to continue"
                : sorted.length === 0 ? "Pick at least one day"
                : conflicts.length ? "Time conflict: join the waitlist or change the time"
                : !sorted.every(k => nameOf(k)) ? "Add an event name to continue"
                : blocker ? blocker
                : `Review ${sorted.length} request${sorted.length === 1 ? "" : "s"}`}
            </button>
          )}
        </div>
        </div>
      </div>
      {notice && <TestBookingNotice waitlist={notice.waitlist} onCancel={() => setNotice(null)}
        onContinue={() => { const run = notice.run; setNotice(null); run(); }} />}
      {showCal && !wide && <BookingCalendar room={room} picks={sorted.map(k => ({ key: k, ...tOf(k) }))} onPick={pickFromCalendar} onClose={() => setShowCal(false)} />}
    </>
  );
}
