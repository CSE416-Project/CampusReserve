import { useEffect, useRef, useState } from 'react';
import useDialog from '../a11y/useDialog.js';
import { useIsPhone, useScrollLock } from '../useMedia.js';
import Avatar from '../components/Avatar.jsx';

const PAGE_SIZE = 12;  // divides evenly into rows of 2 or 3 cards
const STOP = new Set(["with","that","this","from","your","their","them","they","have","will","club","clubs","about","other","into","more","than","also","open","each","where","which","stony","brook","university","students","student","members","member"]);
const words = c => [...new Set(`${c.name} ${c.bio || ""}`.toLowerCase().match(/[a-z]{4,}/g) || [])].filter(w => !STOP.has(w));

export default function Clubs({ clubs, onOpenClub, loading = false }) {
  const CATEGORIES = [...new Set(clubs.map(c => c.category).filter(Boolean))].sort();
  const [q,setQ]=useState(""); const [cats,setCats]=useState([]);
  const [kws,setKws]=useState([]); const [kq,setKq]=useState("");
  const [page,setPage]=useState(1);
  // keywords: words that appear in at least two clubs' names or descriptions, most common first
  const keywordCounts = (() => { const m = {}; clubs.forEach(c => words(c).forEach(w => { m[w] = (m[w] || 0) + 1; }));
    return Object.entries(m).filter(([,n]) => n >= 2).sort((a,b) => b[1]-a[1] || a[0].localeCompare(b[0])).slice(0, 60); })();
  const shownKw = keywordCounts.filter(([w]) => w.includes(kq.toLowerCase().trim()));
  const toggleKw = w => setKws(p => p.includes(w) ? p.filter(x => x !== w) : [...p, w]);
  const toggle = c => setCats(p => p.includes(c) ? p.filter(x => x !== c) : [...p, c]);
  const list = clubs.filter(c => (cats.length === 0 || cats.includes(c.category))
    && (kws.length === 0 || words(c).some(w => kws.includes(w)))
    && `${c.name} ${c.category || ""} ${c.bio}`.toLowerCase().includes(q.toLowerCase()));

  // Back to page 1 whenever the filters (or the club list) change.
  useEffect(() => setPage(1), [clubs, q, cats, kws]);
  const pageCount = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  const current = Math.min(page, pageCount);
  const shown = list.slice((current - 1) * PAGE_SIZE, current * PAGE_SIZE);
  // Phones: filters live in a full-screen sheet opened from the Filters button.
  const isPhone = useIsPhone();
  const [sheet,setSheet]=useState(false);
  const sheetOpen = isPhone && sheet;
  const panel = useRef(null);
  useDialog(panel, { open: sheetOpen, onClose: () => setSheet(false) });
  useScrollLock(sheetOpen);
  const activeFilters = cats.length + kws.length;

  const goTo = p => { setPage(p); window.scrollTo({ top:0, behavior:"smooth" }); };
  const pageBtn = disabled => ({ padding:"8px 14px", borderRadius:10, fontSize:14, fontWeight:600, border:"2px solid var(--ink)",
    color:"var(--ink)", background: disabled ? "var(--paper)" : "var(--blue)", opacity: disabled ? 0.5 : 1,
    cursor: disabled ? "default" : "pointer" });

  return (
    <main className="page" style={{ maxWidth:1100, margin:"0 auto", padding:"26px 24px 60px" }}>
      <h1 style={{ fontSize:26, fontWeight:800, marginBottom:18 }}>Clubs</h1>
      <div className="filters-bar">
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search clubs" aria-label="Search clubs" />
        {(keywordCounts.length > 0 || CATEGORIES.length > 0) && (
          <button className="filters-btn" onClick={()=>setSheet(true)} data-on={activeFilters>0 || undefined} aria-haspopup="dialog">
            Filters{activeFilters>0 && ` (${activeFilters})`}
          </button>
        )}
      </div>
      <div className="filters-layout" style={{ display:"flex", gap:24, alignItems:"flex-start", flexWrap:"wrap" }}>
        <aside ref={panel} className={`filters-panel${sheetOpen ? " open" : ""}`}
          {...(sheetOpen ? { role:"dialog", "aria-modal":true, "aria-labelledby":"club-filters-title", tabIndex:-1 } : {})}
          style={{ width:260, flexShrink:0, background:"var(--card)", border:"2px solid var(--ink)", borderRadius:14, padding:18, boxShadow:"var(--shadow)" }}>
          <div className="sheet-head">
            <h2 id="club-filters-title" style={{ fontSize:20 }}>Filters</h2>
            {activeFilters>0 && <button onClick={()=>{ setCats([]); setKws([]); }} style={{ fontSize:15, fontWeight:700, color:"var(--link)" }}>Clear all</button>}
          </div>
          <div className="hide-phone">
          <label style={{ fontSize:13, fontWeight:600, color:"var(--ink-soft)" }}>Search</label>
          <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Club name or keyword"
            style={{ width:"100%", margin:"6px 0 16px", padding:"9px 11px", fontSize:14.5, border:"2px solid var(--ink)", borderRadius:10, background:"var(--paper)", outline:"none" }} />
          </div>
          {keywordCounts.length > 0 && (
            <div style={{ marginBottom:16 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"baseline", marginBottom:6 }}>
                <label style={{ fontSize:13, fontWeight:600, color:"var(--ink-soft)" }}>Keywords{kws.length > 0 && ` (${kws.length} selected)`}</label>
                {kws.length > 0 && <button onClick={()=>setKws([])} style={{ fontSize:13, fontWeight:600, color:"var(--link)" }}>Clear</button>}
              </div>
              <input id="kw-search" value={kq} onChange={e=>setKq(e.target.value)} placeholder="Search keywords"
                style={{ width:"100%", marginBottom:6, padding:"8px 11px", fontSize:14, border:"2px solid var(--ink)", borderRadius:10, background:"var(--paper)", outline:"none" }} />
              <div className="feature-list" style={{ maxHeight:260, overflowY:"auto", border:"2px solid var(--ink)", borderRadius:10, padding:"4px 10px", background:"var(--paper)" }}>
                {shownKw.map(([w,n]) => (
                  <label key={w} style={{ display:"flex", alignItems:"center", gap:9, padding:"5px 0", fontSize:14.5, cursor:"pointer" }}>
                    <input type="checkbox" checked={kws.includes(w)} onChange={()=>toggleKw(w)} style={{ accentColor:"var(--ink)" }} />
                    <span style={{ flex:1 }}>{w}</span><span style={{ fontSize:13, color:"var(--ink-faint)" }}>{n}</span>
                  </label>
                ))}
                {shownKw.length === 0 && <div style={{ padding:"8px 0", fontSize:14, color:"var(--ink-faint)" }}>No matching keywords</div>}
              </div>
              <div style={{ fontSize:12.5, color:"var(--ink-faint)", marginTop:5 }}>Shows clubs that match any selected keyword.</div>
            </div>
          )}
          {CATEGORIES.length > 0 && <>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"baseline", marginBottom:6 }}>
            <label style={{ fontSize:13, fontWeight:600, color:"var(--ink-soft)" }}>Category{cats.length > 0 && ` (${cats.length})`}</label>
            {cats.length > 0 && <button onClick={()=>setCats([])} style={{ fontSize:13, fontWeight:600, color:"var(--link)" }}>Clear</button>}
          </div>
          {CATEGORIES.map(c => (
            <label key={c} style={{ display:"flex", alignItems:"center", gap:9, padding:"6px 0", fontSize:14.5, cursor:"pointer" }}>
              <input type="checkbox" checked={cats.includes(c)} onChange={()=>toggle(c)} style={{ accentColor:"var(--ink)" }} />
              <span style={{ flex:1 }}>{c}</span>
              <span style={{ fontSize:13, color:"var(--ink-faint)" }}>{clubs.filter(x => x.category === c).length}</span>
            </label>
          ))}
          </>}
          <div className="sheet-foot">
            <button onClick={()=>setSheet(false)} style={{ background:"var(--blue)" }}>
              Show {list.length} club{list.length===1?"":"s"}
            </button>
          </div>
        </aside>

        <div style={{ flex:1, minWidth:280 }}>
          <div style={{ fontSize:14, color:"var(--ink-faint)", fontWeight:600, marginBottom:12 }}>
            {list.length > PAGE_SIZE
              ? `Showing ${(current-1)*PAGE_SIZE+1}–${Math.min(current*PAGE_SIZE, list.length)} of ${list.length} clubs`
              : `${list.length} ${list.length === 1 ? "club" : "clubs"}`}
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(min(270px,100%),1fr))", gap:14 }}>
            {shown.map(c => (
              <button key={c.name} onClick={()=>onOpenClub(c.name)} style={{ textAlign:"left", background:"var(--card)", border:"2px solid var(--ink)",
                borderRadius:14, padding:18, boxShadow:"var(--shadow)" }}>
                <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:10 }}>
                  <Avatar name={c.name} />
                  <div>
                    <div style={{ fontWeight:700, fontSize:16 }}>{c.name}</div>
                    <div style={{ fontSize:13.5, color:"var(--ink-faint)" }}>{c.category ? `${c.category} · ` : ""}{c.count} e-board member{c.count === 1 ? "" : "s"}</div>
                  </div>
                </div>
                <div style={{ fontSize:14, color:"var(--ink-soft)" }}>{c.bio || "No description yet."}</div>
              </button>
            ))}
            {loading && <div style={{ color:"var(--ink-faint)", fontSize:15 }}>Loading clubs…</div>}
            {!loading && list.length === 0 && <div style={{ color:"var(--ink-faint)", fontSize:15 }}>No clubs match those filters.</div>}
          </div>
          {pageCount > 1 && (
            <nav aria-label="Club pages" style={{ display:"flex", justifyContent:"center", alignItems:"center", gap:12, marginTop:18 }}>
              <button onClick={()=>goTo(current-1)} disabled={current===1} style={pageBtn(current===1)}>‹ Previous</button>
              <span style={{ fontSize:14, fontWeight:600 }} aria-current="page">Page {current} of {pageCount}</span>
              <button onClick={()=>goTo(current+1)} disabled={current===pageCount} style={pageBtn(current===pageCount)}>Next ›</button>
            </nav>
          )}
        </div>
      </div>
    </main>
  );
}