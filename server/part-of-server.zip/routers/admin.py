"""Admin endpoints: review queue, 25Live sync, rooms, closures, users, organizations.

Approve/deny themselves live at /requests/{id}/approve and /deny.
"""

from __future__ import annotations

import datetime as dt

from fastapi import APIRouter, Depends, HTTPException, Query, Response, Security, status
from pydantic import BaseModel, Field
from sqlalchemy import func, or_
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload
from starlette.concurrency import run_in_threadpool

from authentication import get_current_user
from database import get_db
from models.communication import NotificationType
from models.organization_and_venue import Organization, OrganizationMember, Venue
from models.room import Request, RequestStatus, Room, RoomClosure, SyncStatus
from models.user import User, UserRole
from routers.requests import CheckOut, RequestOut, SyncOut, request_out
from services import booking, live25_csv, room_features
from services.live25_sync import get_provider, manual_steps
from services.notify import notify
from services.pagination import Page, paged
from services.permissions import admins, as_uuid, can_manage_venue
from services.request_flow import check_booking, load_25live_rooms
from services.room_import import ensure_room, find_room, import_rooms
from services.room_merge import campus_now, to_local_naive

router = APIRouter(prefix="/admin", tags=["admin"])


# =============================================================================
# Review queue
# =============================================================================

class QueueItem(BaseModel):
    request: RequestOut
    check: CheckOut | None = None   # for pending requests: what's in the way now


@router.get("/requests", response_model=list[QueueItem])
async def review_queue(
    response: Response,
    status_: RequestStatus = Query(RequestStatus.PENDING, alias="status"),
    room_id: str | None = None,
    organization_id: str | None = None,
    page: Page = Depends(paged(default_limit=50, max_limit=200)),
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["handle:requests"]),
):
    """Requests to review, oldest first. Pending ones include a fresh check,
    so you can see conflicts (25Live bookings, other approvals, closures,
    competing requests) before approving."""

    def load():
        q = db.query(Request).options(selectinload(Request.room), selectinload(Request.organization), selectinload(Request.requester)).filter(Request.status == status_)
        if room_id:
            room = find_room(db, room_id)
            if room is None:
                response.headers["X-Total-Count"] = "0"
                return []
            q = q.filter(Request.room_id == room.id)
        if organization_id:
            q = q.filter(Request.organization_id == as_uuid(organization_id, "organization"))
        return page.query(q.order_by(Request.created_at, Request.id), response).all()

    items = []
    for req in await run_in_threadpool(load):
        check = None
        if req.status == RequestStatus.PENDING:
            result = await check_booking(db, room=req.room, space_id=req.room.external_ref,
                                         window=booking.window_of(req),
                                         attendance=req.expected_attendance, is_admin=True,
                                         exclude_id=req.id)
            check = CheckOut(**result.to_dict())
        items.append(QueueItem(request=await run_in_threadpool(request_out, req), check=check))
    return items


# =============================================================================
# 25Live sync
# =============================================================================

class SyncItem(BaseModel):
    request: RequestOut
    details: dict
    steps: list[str]


class ConfirmSyncBody(BaseModel):
    external_booking_ref: str = Field(min_length=1, description="The 25Live event reference")


@router.get("/sync", response_model=list[SyncItem])
def sync_queue(
    response: Response,
    include_past: bool = False,
    page: Page = Depends(paged()),
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["sync:external-bookings"]),
):
    """Approved bookings not yet in 25Live (not_synced or failed), soonest
    first, with what to enter in 25Live."""
    q = db.query(Request).options(selectinload(Request.room), selectinload(Request.organization), selectinload(Request.requester)).filter(Request.status == RequestStatus.APPROVED,
                                 Request.sync_status != SyncStatus.SYNCED)
    if not include_past:
        q = q.filter(Request.end_time >= campus_now())
    out = []
    for req in page.query(q.order_by(Request.start_time, Request.id), response).all():
        details = booking.sync_details(req)
        out.append(SyncItem(request=request_out(req), details=details,
                            steps=manual_steps(details)))
    return out


@router.post("/requests/{request_id}/sync", response_model=SyncOut)
async def push_to_25live(
    request_id: str,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["sync:external-bookings"]),
):
    """(Re)send an approved booking to 25Live. In manual mode this returns
    the instructions again; in api mode it retries the automatic push."""

    def load():
        req = booking.get_request(db, request_id)
        if req.status != RequestStatus.APPROVED:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                                detail="Only approved requests are synced to 25Live.")
        if req.sync_status == SyncStatus.SYNCED:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                                detail=f"Already in 25Live ({req.external_booking_ref}).")
        return req, booking.sync_details(req)

    req, details = await run_in_threadpool(load)
    provider = get_provider()
    result = await provider.push(details)

    def save():
        booking.apply_sync_result(db, req, result)
        db.commit()

    await run_in_threadpool(save)
    return SyncOut(mode=provider.mode, status=result.status.value, message=result.message,
                   instructions=result.instructions)


@router.post("/requests/{request_id}/sync/confirm", response_model=RequestOut)
def confirm_sync(
    request_id: str,
    body: ConfirmSyncBody,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["sync:external-bookings"]),
):
    """Manual mode: record that you entered the booking in 25Live, with its
    25Live reference. Marks it synced."""
    req = booking.get_request(db, request_id)
    booking.confirm_manual_sync(db, req, body.external_booking_ref)
    db.commit()
    db.refresh(req)
    return request_out(req)


# =============================================================================
# 25Live CSV export (read-only 25Live: download, then upload in the Data Import Tool)
# =============================================================================

class ExportItem(BaseModel):
    id: str
    event_name: str
    organization: str
    room: str
    date: str
    time: str
    problems: list[str] = []   # can't be exported until fixed
    warnings: list[str] = []   # exported, but worth checking in 25Live


class CancelItem(BaseModel):
    id: str
    event_name: str
    organization: str
    room: str
    date: str
    time: str
    event_id: str              # what 25Live calls it: CSV-<request id>


class ExportBatchOut(BaseModel):
    id: str
    exported_at: dt.datetime
    count: int                 # bookings in the file
    confirmed: int             # of those, how many an admin marked as uploaded


class ExportSettings(BaseModel):
    event_type: str
    primary_organization: str | None   # None: each club's own name is used


class ExportPreview(BaseModel):
    ready: list[ExportItem]
    skipped: list[ExportItem]
    cancellations: list[CancelItem]
    batches: list[ExportBatchOut]
    settings: ExportSettings


class ExportFile(BaseModel):
    batch_id: str
    filename: str
    count: int
    csv: str
    skipped: list[ExportItem] = []


def _when(req: Request) -> tuple[str, str]:
    s, e = req.start_time, req.end_time
    return f"{s:%a %b} {s.day}", f"{s:%I:%M %p}".lstrip("0") + "\u2013" + f"{e:%I:%M %p}".lstrip("0")


def _export_item(row: live25_csv.ExportRow) -> ExportItem:
    req = row.request
    date, time = _when(req)
    return ExportItem(id=str(req.id), event_name=req.event_name,
                      organization=req.organization.name if req.organization else "",
                      room=req.room.name if req.room else "", date=date, time=time,
                      problems=row.problems, warnings=row.warnings)


def _cancel_item(req: Request) -> CancelItem:
    date, time = _when(req)
    return CancelItem(id=str(req.id), event_name=req.event_name,
                      organization=req.organization.name if req.organization else "",
                      room=req.room.name if req.room else "", date=date, time=time,
                      event_id=live25_csv.alien_uid(req))


def _utc(t: dt.datetime) -> dt.datetime:
    return t.replace(tzinfo=dt.timezone.utc) if t.tzinfo is None else t


def _csv_filename() -> str:
    return f"25live-import-{campus_now():%Y%m%d-%H%M}.csv"


@router.get("/sync/export", response_model=ExportPreview)
def export_preview(
    include_past: bool = False,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["sync:external-bookings"]),
):
    """What the next CSV download would hold, plus recent downloads and the
    bookings cancelled after they were downloaded (to cancel in 25Live by hand)."""
    rows = [live25_csv.make_row(r) for r in live25_csv.eligible(db, include_past=include_past)]
    cutoff = dt.datetime.utcnow() - dt.timedelta(days=30)
    batch_rows = (
        db.query(Request.export_batch_id, func.min(Request.exported_at), func.count(Request.id),
                 func.count(Request.id).filter(Request.sync_status == SyncStatus.SYNCED))
        .filter(Request.export_batch_id.isnot(None), Request.exported_at >= cutoff)
        .group_by(Request.export_batch_id)
        .order_by(func.min(Request.exported_at).desc())
        .limit(15).all()
    )
    return ExportPreview(
        ready=[_export_item(r) for r in rows if not r.problems],
        skipped=[_export_item(r) for r in rows if r.problems],
        cancellations=[_cancel_item(r) for r in live25_csv.pending_cancellations(db)],
        batches=[ExportBatchOut(id=b, exported_at=_utc(at), count=n, confirmed=c)
                 for b, at, n, c in batch_rows],
        settings=ExportSettings(event_type=live25_csv.event_type(),
                                primary_organization=live25_csv.primary_organization_override()),
    )


@router.post("/sync/export", response_model=ExportFile)
def export_new(
    include_past: bool = False,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["sync:external-bookings"]),
):
    """Build the CSV of every approved booking that hasn't been downloaded yet,
    and remember that they have been, so the next download skips them. If the
    upload goes wrong, GET /sync/batches/{id}/csv re-downloads it and
    POST /sync/batches/{id}/undo puts the bookings back in the queue."""
    rows = [live25_csv.make_row(r) for r in live25_csv.eligible(db, include_past=include_past, lock=True)]
    good = [r for r in rows if not r.problems]
    if not good:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                            detail="Nothing new to export: every approved booking is already in a file.")
    batch_id = live25_csv.mark_exported([r.request for r in good], dt.datetime.utcnow())
    content = live25_csv.build_csv(good)
    db.commit()
    return ExportFile(batch_id=batch_id, filename=_csv_filename(), count=len(good), csv=content,
                      skipped=[_export_item(r) for r in rows if r.problems])


def _batch_or_404(db: Session, batch_id: str, *, lock: bool = False) -> list[Request]:
    reqs = live25_csv.batch_requests(db, batch_id, lock=lock)
    if not reqs:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No such export.")
    return reqs


@router.get("/sync/batches/{batch_id}/csv", response_model=ExportFile)
def redownload_batch(
    batch_id: str,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["sync:external-bookings"]),
):
    """The same file again (e.g. the upload failed). Bookings cancelled since are left out."""
    reqs = _batch_or_404(db, batch_id)
    rows = [live25_csv.make_row(r) for r in reqs if r.status == RequestStatus.APPROVED]
    good = [r for r in rows if not r.problems]
    if not good:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                            detail="Every booking in this export has since been cancelled.")
    return ExportFile(batch_id=batch_id, filename=_csv_filename(), count=len(good),
                      csv=live25_csv.build_csv(good), skipped=[_export_item(r) for r in rows if r.problems])


@router.get("/sync/batches/{batch_id}/details", response_model=ExportFile)
def batch_details_sheet(
    batch_id: str,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["sync:external-bookings"]),
):
    """A companion sheet for the admin (not for upload to 25Live): the export's requests with
    every event question as its own Yes/No column. Bookings cancelled since are left out."""
    reqs = [r for r in _batch_or_404(db, batch_id) if r.status == RequestStatus.APPROVED]
    if not reqs:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                            detail="Every booking in this export has since been cancelled.")
    return ExportFile(batch_id=batch_id, filename=_csv_filename().replace("25live-import", "25live-details"),
                      count=len(reqs), csv=live25_csv.build_details_csv(reqs), skipped=[])


@router.post("/sync/batches/{batch_id}/undo")
def undo_batch(
    batch_id: str,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["sync:external-bookings"]),
):
    """The file was never uploaded: put its bookings back in the queue for the
    next download. Bookings already confirmed as uploaded stay confirmed."""
    reqs = _batch_or_404(db, batch_id, lock=True)
    released = [r for r in reqs if r.sync_status != SyncStatus.SYNCED]
    if not released:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                            detail="This export is already confirmed as uploaded.")
    for r in released:
        r.exported_at = None
        r.export_batch_id = None
    db.commit()
    return {"released": len(released)}


@router.post("/sync/batches/{batch_id}/confirm")
def confirm_batch(
    batch_id: str,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["sync:external-bookings"]),
):
    """The file was uploaded in 25Live: mark its approved bookings as synced
    (25Live now has them), recording the id 25Live gave them (CSV-<request id>)."""
    reqs = _batch_or_404(db, batch_id, lock=True)
    todo = [r for r in reqs if r.status == RequestStatus.APPROVED and r.sync_status != SyncStatus.SYNCED]
    for r in todo:
        r.sync_status = SyncStatus.SYNCED
        r.external_booking_ref = live25_csv.alien_uid(r)
    db.commit()
    return {"confirmed": len(todo)}


@router.post("/sync/cancellations/{request_id}/done")
def cancellation_done(
    request_id: str,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["sync:external-bookings"]),
):
    """The cancelled booking has been cancelled in 25Live too."""
    req = booking.get_request(db, request_id)
    if req.status != RequestStatus.CANCELLED or req.exported_at is None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                            detail="This booking doesn't need cancelling in 25Live.")
    req.cancel_handled_at = dt.datetime.utcnow()
    db.commit()
    return {"ok": True}


# =============================================================================
# Rooms
# =============================================================================

class RoomUpdate(BaseModel):
    """Only the fields you send are changed. Send null to clear a field."""
    name: str | None = Field(None, min_length=1, max_length=255)
    capacity: int | None = Field(None, ge=0)
    room_type: str | None = Field(None, max_length=100)
    features: list[str] | None = Field(None, description="Feature tags, see GET /rooms/features")
    media_url: str | None = Field(None, max_length=512)
    club_bookable: bool | None = None
    is_active: bool | None = None
    booking_opens_days_ahead: int | None = Field(None, ge=0, le=730)


class RoomAdminOut(BaseModel):
    id: str
    db_id: str
    venue_id: str
    venue_name: str | None
    name: str
    capacity: int | None
    room_type: str | None
    features: list[str]
    media_url: str | None
    club_bookable: bool
    is_active: bool
    booking_opens_days_ahead: int | None


def room_out(room: Room) -> RoomAdminOut:
    return RoomAdminOut(
        id=room.external_ref or str(room.id), db_id=str(room.id), venue_id=str(room.venue_id),
        venue_name=room.venue.name if room.venue else None, name=room.name,
        capacity=room.capacity, room_type=room.room_type, features=list(room.features or []),
        media_url=room.media_url, club_bookable=room.club_bookable, is_active=room.is_active,
        booking_opens_days_ahead=room.booking_opens_days_ahead)


class ImportBody(BaseModel):
    building: str | None = Field(None, description="Only rooms in buildings matching this")
    space_ids: list[str] | None = Field(None, description="Only these 25Live rooms")


@router.post("/rooms/import")
async def import_from_25live(
    body: ImportBody | None = None,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["manage:rooms"]),
):
    """Create Room/Venue rows for 25Live rooms we don't have yet. Safe to run
    again: existing rooms (and admins' edits) are left alone. Admins only."""
    if user.role != UserRole.ADMIN:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail="Only admins can import rooms.")
    spaces, info = await load_25live_rooms()

    def run():
        counts = import_rooms(db, spaces, info,
                              only_ids=set(body.space_ids) if body and body.space_ids else None,
                              building=body.building if body else None)
        db.commit()
        return counts

    return await run_in_threadpool(run)


@router.patch("/rooms/{room_id}", response_model=RoomAdminOut)
async def update_room(
    room_id: str,
    body: RoomUpdate,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["manage:rooms"]),
):
    """Set a room's tags (food, crafts, ...), bookability, booking window,
    and details. Venue hosts can edit only rooms in their venues."""
    spaces, info = await load_25live_rooms() if room_id.isdigit() else ([], {})
    changes = body.model_dump(exclude_unset=True)
    if "features" in changes:
        tags = sorted({room_features.normalize(t) for t in changes["features"] or []})
        unknown = [t for t in tags if t not in room_features.FEATURES]
        if unknown:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                detail={"message": f"Unknown feature tags: {', '.join(unknown)}",
                                        "valid_tags": sorted(room_features.FEATURES)})
        changes["features"] = tags
    for required in ("name", "club_bookable", "is_active"):
        if required in changes and changes[required] is None:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                detail=f"{required} can't be empty.")

    def save():
        room = ensure_room(db, room_id, spaces, info)
        if room is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Room not found.")
        if not can_manage_venue(db, user, room.venue_id):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                                detail="You can only edit rooms in venues you host.")
        for field, value in changes.items():
            setattr(room, field, value)
        try:
            db.commit()
        except IntegrityError:
            db.rollback()
            raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                                detail="Another room in this venue already has that name.")
        db.refresh(room)
        return room_out(room)

    return await run_in_threadpool(save)


# =============================================================================
# Closures
# =============================================================================

class ClosureIn(BaseModel):
    room_id: str | None = Field(None, description="Close one room (25Live id or room UUID)")
    venue_id: str | None = Field(None, description="Or close a whole building (venue UUID)")
    closed_from: dt.datetime
    closed_until: dt.datetime
    reason: str = Field(min_length=1, description="Shown to users, e.g. 'HVAC maintenance'")


class ClosureOut(BaseModel):
    id: str
    room_id: str | None
    room_name: str | None
    venue_id: str | None
    venue_name: str | None
    closed_from: dt.datetime
    closed_until: dt.datetime
    reason: str
    affected_requests: list[RequestOut] = []   # bookings/requests inside the closure


def closure_out(c: RoomClosure, affected: list[Request] = ()) -> ClosureOut:
    return ClosureOut(
        id=str(c.id),
        room_id=(c.room.external_ref or str(c.room.id)) if c.room else None,
        room_name=c.room.name if c.room else None,
        venue_id=str(c.venue_id) if c.venue_id else None,
        venue_name=c.venue.name if c.venue else None,
        closed_from=c.closed_from, closed_until=c.closed_until, reason=c.reason,
        affected_requests=[request_out(r) for r in affected])


def _affected(db: Session, c: RoomClosure) -> list[Request]:
    q = db.query(Request).join(Room, Room.id == Request.room_id).filter(
        Request.status.in_(booking.OPEN_STATUSES),
        booking.BLOCK_START < c.closed_until, booking.BLOCK_END > c.closed_from)
    q = q.filter(Request.room_id == c.room_id) if c.room_id else q.filter(Room.venue_id == c.venue_id)
    return q.order_by(Request.start_time).all()


@router.get("/closures", response_model=list[ClosureOut])
def list_closures(
    response: Response,
    room_id: str | None = None,
    venue_id: str | None = None,
    include_past: bool = False,
    page: Page = Depends(paged()),
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["manage:rooms"]),
):
    q = db.query(RoomClosure)
    if room_id:
        room = find_room(db, room_id)
        if room is None:
            response.headers["X-Total-Count"] = "0"
            return []
        q = q.filter(or_(RoomClosure.room_id == room.id, RoomClosure.venue_id == room.venue_id))
    if venue_id:
        q = q.filter(RoomClosure.venue_id == as_uuid(venue_id, "venue"))
    if not include_past:
        q = q.filter(RoomClosure.closed_until >= campus_now())
    return [closure_out(c) for c in page.query(q.order_by(RoomClosure.closed_from, RoomClosure.id), response).all()]


@router.post("/closures", response_model=ClosureOut, status_code=status.HTTP_201_CREATED)
async def create_closure(
    body: ClosureIn,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["manage:rooms"]),
):
    """Close a room or a whole building for a period (maintenance, holidays).
    New requests for that time are refused. Existing bookings inside it are
    NOT cancelled automatically; they're listed in `affected_requests` so you
    can contact or cancel them."""
    if (body.room_id is None) == (body.venue_id is None):
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail="Give exactly one of room_id or venue_id.")
    start, end = to_local_naive(body.closed_from), to_local_naive(body.closed_until)
    if end <= start:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                            detail="closed_until must be after closed_from.")
    spaces, info = (await load_25live_rooms()) if body.room_id and body.room_id.isdigit() \
        else ([], {})

    def save():
        room = venue = None
        if body.room_id:
            room = ensure_room(db, body.room_id, spaces, info)
            if room is None:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Room not found.")
            venue_id = room.venue_id
        else:
            venue = db.get(Venue, as_uuid(body.venue_id, "venue"))
            if venue is None:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Venue not found.")
            venue_id = venue.id
        if not can_manage_venue(db, user, venue_id):
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                                detail="You can only close rooms in venues you host.")
        c = RoomClosure(room_id=room.id if room else None, venue_id=venue.id if venue else None,
                        closed_from=start, closed_until=end, reason=body.reason.strip(),
                        created_by_id=user.id)
        db.add(c)
        db.commit()
        db.refresh(c)
        return closure_out(c, _affected(db, c))

    return await run_in_threadpool(save)


@router.delete("/closures/{closure_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_closure(
    closure_id: str,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["manage:rooms"]),
):
    c = db.get(RoomClosure, as_uuid(closure_id, "closure"))
    if c is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Closure not found.")
    venue_id = c.venue_id or (c.room.venue_id if c.room else None)
    if not can_manage_venue(db, user, venue_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN,
                            detail="You can only change closures in venues you host.")
    db.delete(c)
    db.commit()


# =============================================================================
# Users and organizations
# =============================================================================

class MembershipOut(BaseModel):
    organization_id: str
    organization_name: str | None
    user_id: str
    user_name: str | None
    user_email: str | None
    position_title: str | None
    term_start: dt.date
    term_end: dt.date | None
    verified: bool
    verified_at: dt.datetime | None


def membership_out(m: OrganizationMember) -> MembershipOut:
    return MembershipOut(
        organization_id=str(m.organization_id),
        organization_name=m.organization.name if m.organization else None,
        user_id=str(m.user_id), user_name=m.user.name if m.user else None,
        user_email=m.user.email if m.user else None, position_title=m.position_title,
        term_start=m.term_start, term_end=m.term_end, verified=m.verified_at is not None,
        verified_at=m.verified_at)


class UserAdminOut(BaseModel):
    id: str
    email: str | None
    username: str | None = None
    name: str
    role: str
    is_active: bool
    memberships: list[MembershipOut]


def user_out(u: User) -> UserAdminOut:
    return UserAdminOut(id=str(u.id), email=u.email, username=u.username, name=u.name, role=u.role.value,
                        is_active=u.is_active,
                        memberships=[membership_out(m) for m in u.organization_memberships])


class UserUpdate(BaseModel):
    role: UserRole | None = None
    is_active: bool | None = None


class VerifyBody(BaseModel):
    position_title: str | None = Field(None, max_length=100)
    term_end: dt.date | None = Field(None, description="When their access should end (NFR-2)")


class OrganizationIn(BaseModel):
    name: str = Field(min_length=1, max_length=255)
    description: str | None = None


@router.get("/users", response_model=list[UserAdminOut])
def list_users(
    response: Response,
    role: UserRole | None = None,
    awaiting_verification: bool = Query(False, description="Only users with an unverified membership"),
    search: str | None = Query(None, description="Name or email contains"),
    page: Page = Depends(paged(default_limit=500, max_limit=500)),
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["manage:users"]),
):
    q = db.query(User)
    if role:
        q = q.filter(User.role == role)
    if search:
        like = f"%{search.lower()}%"
        q = q.filter(or_(func.lower(User.name).like(like), func.lower(User.email).like(like),
                         func.lower(User.username).like(like)))
    if awaiting_verification:
        q = q.join(OrganizationMember, OrganizationMember.user_id == User.id).filter(
            OrganizationMember.verified_at.is_(None)).distinct()
    return [user_out(u) for u in page.query(q.order_by(User.name, User.id), response).all()]


@router.patch("/users/{user_id}", response_model=UserAdminOut)
def update_user(
    user_id: str,
    body: UserUpdate,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["manage:users"]),
):
    """Change a user's role or deactivate them. A role change takes effect
    the next time they log in (their current token keeps its old scopes)."""
    target = db.get(User, as_uuid(user_id, "user"))
    if target is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found.")
    if target.id == user.id and (body.is_active is False or
                                 (body.role and body.role != UserRole.ADMIN)):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                            detail="You can't remove your own admin access.")
    if body.role is not None and body.role != UserRole.GENERAL and not target.email:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                            detail="This account has no email, so it can only be a general account.")
    if body.role is not None:
        target.role = body.role
    if body.is_active is not None:
        target.is_active = body.is_active
    db.commit()
    db.refresh(target)
    return user_out(target)


@router.post("/organizations", status_code=status.HTTP_201_CREATED)
def create_organization(
    body: OrganizationIn,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["manage:users"]),
):
    org = Organization(name=body.name.strip(), description=body.description)
    db.add(org)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT,
                            detail="An organization with that name already exists.")
    return {"id": str(org.id), "name": org.name, "description": org.description}


@router.post("/organizations/{organization_id}/members/{user_id}/verify",
             response_model=MembershipOut)
def verify_member(
    organization_id: str,
    user_id: str,
    body: VerifyBody | None = None,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["manage:users"]),
):
    """Verify someone as a current E-board member (NFR-1), so they can book
    for the organization. Creates the membership if they hadn't asked to join."""
    org = db.get(Organization, as_uuid(organization_id, "organization"))
    target = db.get(User, as_uuid(user_id, "user"))
    if org is None or target is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,
                            detail="Organization or user not found.")
    m = db.get(OrganizationMember, (target.id, org.id))
    if m is None:
        m = OrganizationMember(user_id=target.id, organization_id=org.id,
                               term_start=dt.date.today())
        db.add(m)
    if body and body.position_title is not None:
        m.position_title = body.position_title
    if body and body.term_end is not None:
        if body.term_end < (m.term_start or dt.date.today()):
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                                detail="term_end can't be before the term starts.")
        m.term_end = body.term_end
    m.verified_at = dt.datetime.utcnow()
    m.verified_by_id = user.id
    notify(db, [target], NotificationType.MEMBERSHIP_VERIFIED,
           f"You're verified as a member of {org.name} and can now book rooms for it.",
           email_subject=f"Verified for {org.name}")
    db.commit()
    db.refresh(m)
    return membership_out(m)


@router.delete("/organizations/{organization_id}/members/{user_id}",
               status_code=status.HTTP_204_NO_CONTENT)
def remove_member(
    organization_id: str,
    user_id: str,
    db: Session = Depends(get_db),
    user: User = Security(get_current_user, scopes=["manage:users"]),
):
    """End someone's membership. Verified members' terms end today (their
    history stays); unverified join requests are simply removed."""
    m = db.get(OrganizationMember, (as_uuid(user_id, "user"),
                                    as_uuid(organization_id, "organization")))
    if m is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Membership not found.")
    if m.verified_at is None:
        db.delete(m)
    else:
        m.term_end = max(dt.date.today(), m.term_start)
    db.commit()


def notify_admins_of_join(db: Session, member: User, org: Organization) -> None:
    notify(db, admins(db), NotificationType.MEMBERSHIP_REQUESTED,
           f"{member.name} ({member.email}) asked to be verified for {org.name}. ",
           email_subject="Membership waiting for verification")
